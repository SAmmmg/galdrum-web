import{H as r,P as t}from"./D_SDDevN.js";const n=({from:a,replacement:o,scope:s,version:m,ref:p,type:c="API"},e)=>{r(()=>t(e),f=>{},{immediate:!0})};export{n as u};
