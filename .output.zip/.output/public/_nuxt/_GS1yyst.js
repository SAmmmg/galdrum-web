import"./D_SDDevN.js";const o=""+new URL("Group 622.VSuBKea7.png",import.meta.url).href;export{o as _};
