import{v as t,B as a,Z as r,t as o}from"./D_SDDevN.js";const c={__name:"empty",setup(s){return(e,l)=>(o(),t("div",null,[a(" empty "),r(e.$slots,"default")]))}};export{c as default};
