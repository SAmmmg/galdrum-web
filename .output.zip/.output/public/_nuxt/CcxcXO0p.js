import{x as n}from"./bHIVFirJ.js";import{K as o}from"./D_SDDevN.js";function a(e){const t=o();t&&n(t.proxy,e)}export{a as u};
