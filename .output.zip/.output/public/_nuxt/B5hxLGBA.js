import{_ as c,v as e,t as o}from"./D_SDDevN.js";const n={};function t(r,s){return o(),e("div",null,"coupon")}const a=c(n,[["render",t]]);export{a as default};
