import{L as s}from"./D_SDDevN.js";const p=s("/image/bao.png");export{p as _};
