import{K as o}from"./D_SDDevN.js";const t=()=>{var e;const{scopeId:n}=((e=o())==null?void 0:e.vnode)||{};return n?{[n]:""}:null};export{t as u};
