import{L as s}from"./D_SDDevN.js";const p=s("/image/qrcode.png");export{p as _};
