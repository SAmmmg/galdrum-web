import{L as s}from"./D_SDDevN.js";const t=s("/image/avatar.png");export{t as _};
