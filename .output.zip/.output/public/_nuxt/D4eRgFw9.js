import{L as s}from"./D_SDDevN.js";const p=s("/image/banner.png");export{p as _};
